package com.example.demo;

public class Customer {
	private String name;
	private String password;
	private int age;
	private String dept;
	private int mobile;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String password, int age, String dept, int mobile) {
		super();
		this.name = name;
		this.password = password;
		this.age = age;
		this.dept = dept;
		this.mobile = mobile;
	}
	
}
