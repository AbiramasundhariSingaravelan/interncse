package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CustomerController {

	@RequestMapping("/welcome")
	public String demo()
	{
		return "welcome";//file name
	}
	@RequestMapping("/userlogin")
	public String showLogin()
	{
		return "login";
	}
	@RequestMapping("/signup")
	public String signup()
	{
		return "signup";
	}
	@RequestMapping(value="/postdata",method=RequestMethod.GET)
	public String showSignUp(@ModelAttribute("customer") Customer c,ModelMap m)
	{
		m.addAttribute("name",name);
		m.addAttribute("password",password);
		m.addAttribute("age",age);
		m.addAttribute("dept",dept);
		m.addAttribute("mobile",mobile);	
		return "data";
	}
	@RequestMapping("/contact")
	public String showContact()
	{
		return "contact";
	}
}
