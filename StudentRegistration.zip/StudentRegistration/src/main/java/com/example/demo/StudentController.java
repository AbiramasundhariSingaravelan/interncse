package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class StudentController {

	@Autowired
	StudentRepository repo;
	@RequestMapping("/register")
	public String registerForm()
	{
		return "register";
	}
	@RequestMapping("/addData")
	public String addData(@RequestParam("id") int id,@RequestParam("name") String name, @RequestParam("dept") String dept, @RequestParam("batch") String batch, @RequestParam("addr") String addr,Student s,Model m)
	{
		s.setId(id);
		s.setName(name);
		s.setAddr(addr);
		s.setBatch(batch);
		s.setDept(dept);
		m.addAttribute("id",id);
		m.addAttribute("name",name);
		m.addAttribute("dept",dept);
		m.addAttribute("batch",batch);
		m.addAttribute("addr",addr);
		repo.save(s);
		return "data";
	}
	@RequestMapping("/viewAll")
	@ResponseBody
	public List<Student> viewAllData()
	{
		return repo.findAll();
		
	}
	//localhost:80802/viewById/100
	@RequestMapping("/viewById/{id}")
	@ResponseBody
	public Optional<Student> ViewDataById(@PathVariable int id)
	{
		return repo.findById(id);
	}
	@RequestMapping("/deleteById/{id}")
	public String delete(@PathVariable int id)
	{
		repo.deleteById(id);
		return "delete";
	}
	@RequestMapping("/update/{id}")
	@ResponseBody
	public Student update(@PathVariable int id, Student s) throws Exception
	{
		Student stud=repo.findById(id).orElseThrow(()->new Exception("Not Found"));
		stud.setName("aa");
		stud.setDept("CSE");
		stud.setBatch("I");
		stud.setAddr("Chennai");
		return repo.save(stud);
	}
}
