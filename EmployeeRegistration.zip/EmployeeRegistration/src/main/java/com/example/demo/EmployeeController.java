package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeRepository repo;
	@PostMapping("/addData")
	public Employee addEmployee(@RequestBody Employee e) {
		
		e.setEid(e.getEid());
		e.setName(e.getName());
		e.setDesign(e.getDesign());
		e.setSalary(e.getSalary());
		return repo.save(e);
	}
}
