package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomerController {

	@RequestMapping("/welcome")
	public String demo()
	{
		return "welcome";//file name
	}
	@RequestMapping("/userlogin")
	public String showLogin()
	{
		return "login";
	}
	@RequestMapping("/signup")
	public String showSignUp()
	{
		return "signup";
	}
	@RequestMapping("/contact")
	public String showContact()
	{
		return "contact";
	}
}
